<?php

return [
    'auth' => [
        'forget_password' => 'Chúng tôi đã gửi một liên kết đến Email của bạn. Vui lòng nhấn vào liên kết trong Email để bắt đầu thay đổi mật khẩu.',
        'send_mail_after_register' => 'Đăng ký thành công. Chúng tôi đã gửi link xác thực vào Email của bạn. Vui lòng xác thực Email để hoàn tất đăng ký.',
        'login_not_verify_email' => 'Tài khoản chưa xác thực Email. Chúng tôi đã gửi một liên kết tới Email của bạn, vui lòng kiểm tra thư'
    ]
];